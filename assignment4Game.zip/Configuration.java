package assignment4Game;

public class Configuration {
	
	public int[][] board;
	public int[] available;
	boolean spaceLeft;
	
	public Configuration(){
		board = new int[7][6];
		available = new int[7];
		spaceLeft = true;
	}
	
	public void print(){
		System.out.println("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |");
		System.out.println("+---+---+---+---+---+---+---+");
		for (int i = 0; i < 6; i++){
			System.out.print("|");
			for (int j = 0; j < 7; j++){
				if (board[j][5-i] == 0){
					System.out.print("   |");
				}
				else{
					System.out.print(" "+ board[j][5-i]+" |");
				}
			}
			System.out.println();
		}
	}
	
	public void addDisk (int index, int player){
		// ADD YOUR CODE HERE
		this.board[index][this.available[index]] = player;  //add to the avaiable one 
		this.available[index] ++;
		this.spaceLeft = false; 
		for (int i = 0 ; i <= 6 ; i ++){
			if(this.available[i] < 7 ){ //loop through each one, if space left update to true 
				this.spaceLeft = true; 
			}
		}

	}

	private int findRow( int lastColumnPlayed, int player ) {
		int placein = 0;
		while( this.board[lastColumnPlayed][ placein ]!=0 ) {
			if( placein  == 5 ) {
				return 5;
			}
			placein ++;
		}
		return placein - 1;
	}
	private boolean Diagonal( int column, int row, int player) {  
		//bottom left to top right
		int a;
		int b;
		int count = 0;
		if (column >= row) { 
			a = column - row;
			b = 0;
		} 
		else {
			a = 0;
			b = row - column;
		}
		while (a <= 6 && b <= 5) {
			if (this.board[a][b] == player) {
				count++;
			} 
			else {
				count = 0;
			}
			if (count >= 4) {
				return true;
			}
			a++;
			b++;
		}
		//top left to bottom right
		count=0;
		int a2;
		int b2;
		int sum = column+row;
		if(sum > 5) {
			b2 = 5;
			a2 = sum - 5;
		}
		else {
			a2 = 0;
			b2 = sum;
		}
		while (a2 <= 6 && b2 >= 0) {
			if (this.board[a2][b2] == player) {
				count++;
			} 
			else {
				count = 0;
			}
			if (count >= 4) {
				return true;
			}
			a2++;
			b2--;
		}
		return false;
	}

	public boolean isWinning (int lastColumnPlayed, int player){
		// ADD YOUR CODE HERE
		int row = findRow(lastColumnPlayed, player);
		int winamount = 0 ;
		//row 
			int winamountRow = 0;
			for(int j = 0 ; j < 7 ; j ++){
				if(this.board[j][row] == player ){ //pass through each row to find 
					winamountRow ++; 
				}
				else{
					winamountRow = 0; // no adding 
				}
				if( winamountRow > 3 ){
					return true; 
				}
			}			
		//colomn
			for(int downrow = row - 1 ; downrow >= 0; downrow -- ){
				if(this.board[lastColumnPlayed][downrow] == player){
					winamount ++;
				}
				else{
					winamount = 0; //no adding  
				}
				if(winamount >= 3){ //wins! larger than 3 in colomn 
					return true; 
				}
			}
		//diagnol 
			if( Diagonal(lastColumnPlayed, row, player) == true ){
				return true; 
			}


		return false; // DON'T FORGET TO CHANGE THE RETURN
	}
	
	public int canWinNextRound (int player){
		// ADD YOUR CODE HERE
		if(this.spaceLeft == false ){ // there is no such colomn 
			return -1; 
		}
		for(int i = 0 ; i < 7 ; i ++){
			if(this.available[i] < 6 ){ //still has space 
				this.addDisk(i, player);
				if(this.isWinning(i, player) == true ){ //it wins 
					int current = this.findRow( i , player); //our player current height 
					this.board[i][current] = 0;
					this.available[i] -- ;
					return i ; //return the one on 
				}
				int current = this.findRow( i , player); //our player current height 
				this.board[i][current] = 0;
				this.available[i] -- ; // no wining no return i, return -1 
			}
		}
		
		return -1;
	}
	
	public int canWinTwoTurns (int player){
		// ADD YOUR CODE HERE
		int player2;
		if(player == 1 ){
			player2 = 2; 
		}
		else{
			player2 = 1;
		}
		for (int i = 0; i < 7; i++) {
			if ( available[ i ] < 6 ) {
				addDisk( i , player);
				if( this.canWinNextRound(player2) >= 0) {
					int current = this.findRow( i , player); 
					this.board[i][current] = 0;
					this.available[i] -- ;
					continue;
				}
				else {
					for(int j = 0;j < 7; j ++ ) {
						if(this.available[j] < 6) {
							this.addDisk(j, player2);
							if(this.canWinNextRound(player)<0) {
								int current = this.findRow( j , player2 ); 
								this.board[j][current] = 0;
								this.available[j] -- ;
								break;
							}
							int current = this.findRow( j , player2 ); 
							this.board[j][current] = 0;
							this.available[j] -- ;
						}
						if(j == 6) {
							int current = this.findRow( i , player ); 
							this.board[i][current] = 0;
							this.available[i] -- ;
							return i;
						}
					}
				}
				
				int current = this.findRow( i , player ); 
				this.board[i][current] = 0;
				this.available[i] -- ;
			}
		}
		return -1; // DON'T FORGET TO CHANGE THE RETURN
	}
	
}
