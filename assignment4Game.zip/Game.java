package assignment4Game;

import java.io.*;

public class Game {
	
	public static int play(InputStreamReader input){
		BufferedReader keyboard = new BufferedReader(input);
		Configuration c = new Configuration();
		int columnPlayed = 3; int player;
		
		// first move for player 1 (played by computer) : in the middle of the grid
		c.addDisk(firstMovePlayer1(), 1);
		int nbTurn = 1;
		
		while (nbTurn < 42){ // maximum of turns allowed by the size of the grid
			player = nbTurn %2 + 1;
			if (player == 2){
				columnPlayed = getNextMove(keyboard, c, 2);
			}
			if (player == 1){
				columnPlayed = movePlayer1(columnPlayed, c);
			}
			System.out.println(columnPlayed);
			c.addDisk(columnPlayed, player);
			if (c.isWinning(columnPlayed, player)){
				c.print();
				System.out.println("Congrats to player " + player + " !");
				return(player);
			}
			nbTurn++;
		}
		return -1;
	}
	
	public static int getNextMove(BufferedReader keyboard, Configuration c, int player){
		// ADD YOUR CODE HERE
		int buf = -1; //buffer to contain input 
		boolean win = false;
		while (win == false ){
			try{
				c.print();
				keyboard = new BufferedReader(new InputStreamReader(System.in)); //read from input
				buf = Integer.parseInt( keyboard.readLine() );
				if (buf > 6 || buf < 0) {  // a valid input should be from 1~5 
					throw new IllegalArgumentException();
				}
				if (c.available[buf] > 5) {
					throw new IllegalArgumentException();
				}
				else { 
					win = true;
					return buf; 
				}				
			}
			catch(IOException e1){
				System.out.print(" catch an IO exception ");
			}
			catch(IllegalArgumentException e2 ){
				System.out.print(" catch an Illegal argument Exception ");
			}
		}
		return buf;
	}
	
	public static int firstMovePlayer1 (){
		return 3;
	}
	public static int beside( int column  ,Configuration con ){
	if(con.available[ column ] < 6 ) {
		return column;
	}
	int L = column - 1;
	int R = column + 1;
	while( L >= 0 || R <= 6 ){
		if(L >= 0 && con.available[L] <6){
			return L;
		}
		else{
			L--;
		}
		if(R <= 6 && con.available[R] < 6 ){
			return R;
		}
		else{
			R++;
		}

	}
	return -1;
	}

	public static int movePlayer1 (int columnPlayed2, Configuration c){
		int move = -1;
		if(c.spaceLeft == false ){
			return -1; 
		}
		if(c.canWinNextRound(1) >= 0 ){
			move = c.canWinNextRound(1);
			return move; 
		}
		else if(c.canWinTwoTurns(1) >= 0){
			move = c.canWinTwoTurns(1);
			return move;
		}
		else{
			if(c.available[columnPlayed2] < 6 ){
				return columnPlayed2; 
			}
			else if(c.available[columnPlayed2] >= 6 ){
				move = beside(columnPlayed2, c);
				return move;
			}
			else{
				return -1; 
			}
		}
	}
	
}
