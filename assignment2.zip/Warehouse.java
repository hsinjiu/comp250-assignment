package assignment2;

public class Warehouse{

	protected Shelf[] storage;
	protected int nbShelves;
	public Box toShip;
	public UrgentBox toShipUrgently;
	static String problem = "problem encountered while performing the operation";
	static String noProblem = "operation was successfully carried out";
	private Shelf[] helper; //add a helper array for merge
	
	public Warehouse(int n, int[] heights, int[] lengths){
		this.nbShelves = n;
		this.storage = new Shelf[n];
		for (int i = 0; i < n; i++){
			this.storage[i]= new Shelf(heights[i], lengths[i]);
		}
		this.toShip = null;
		this.toShipUrgently = null;
	}
	
	public String printShipping(){
		Box b = toShip;
		String result = "not urgent : ";
		while(b != null){
			result += b.id + ", ";
			b = b.next;
		}
		result += "\n" + "should be already gone : ";
		b = toShipUrgently;
		while(b != null){
			result += b.id + ", ";
			b = b.next;
		}
		result += "\n";
		return result;
	}
	
 	public String print(){
 		String result = "";
		for (int i = 0; i < nbShelves; i++){
			result += i + "-th shelf " + storage[i].print();
		}
		return result;
	}
	
 	public void clear(){
 		toShip = null;
 		toShipUrgently = null;
 		for (int i = 0; i < nbShelves ; i++){
 			storage[i].clear();
 		}
 	}
 	
 	/**
 	 * initiate the merge sort algorithm
 	 */
	public void sort(){
		mergeSort(0, nbShelves -1);
	}
	
	/**
	 * performs the induction step of the merge sort algorithm
	 * @param start
	 * @param end
	 */
	protected void mergeSort(int start, int end){
		//ADD YOUR CODE HERE
		if(start <end) {
			int middle = start + (end - start)/2;
			mergeSort(start, middle);
			mergeSort(middle +1, end);
			merge(start, middle, end);
		}
	}
	
	/**
	 * performs the merge part of the merge sort algorithm
	 * @param start
	 * @param mid
	 * @param end
	 */
	protected void merge(int start, int mid, int end){
		//ADD YOUR CODE HERE
		helper = new Shelf[10000]; // the helper array 
		for(int i = start ; i <= end; i++) {
			helper[i] = storage[i];
		}
		int i = start;
		int j = mid +1;
		int k = start; 
		while(i <=  mid && j <= end ) {
			if(helper[i].height <= helper[j].height) {
				storage[k] = helper[i]; 
				i++;
			}
			else {
				storage[k] = helper[j];
				j++;
			}
			k++;
		}
		while(i<= mid) {
			storage[k] = helper[i];
			k++;
			i++;
		}
	}
	
	/**
	 * Adds a box is the smallest possible shelf where there is room available.
	 * Here we assume that there is at least one shelf (i.e. nbShelves >0)
	 * @param b
	 * @return problem or noProblem
	 */
	public String addBox (Box b){
		//ADD YOUR CODE HERE
		
		int bheight = b.height; 
		int n; 
		for(n =0 ; n <this.nbShelves; n++) {
			if(storage[n].height >= bheight) { //the height can fit  
				if(storage[n].availableLength >= b.length ) { //still have space to  fit 
					storage[n].addBox(b);	
					return noProblem;
				}
			}
		}
			return problem; 
	}


	
	/**
	 * Adds a box to its corresponding shipping list and updates all the fields
	 * @param b
	 * @return problem or noProblem
	 */
    public String addToShip (Box b){
		//ADD YOUR CODE HERE
        try {
            if(b != null){
                if (b instanceof UrgentBox){
                    if(toShipUrgently == null){  // if it is emptry 
                        toShipUrgently = (UrgentBox)b;
                        toShipUrgently.previous = null;
                        toShipUrgently.next = null;
                        return noProblem;
                    }
                    else{
                        toShipUrgently.previous = b; //link to orignial 
                        Box UrgtempB = toShipUrgently;
                        toShipUrgently = (UrgentBox)b; //field update 
                        toShipUrgently.next = UrgtempB;
                        return noProblem; 
                    }
                }
                else{
                    if(toShip == null){  // if it is emptry 
                        toShip = b;
                        toShip.previous = null;
                        toShip.next = null;
                        return noProblem; 
                    }
                    else{
                        toShip.previous = b; //link to orignial 
                        Box ShipTempB = toShip;
                        toShip = b; //field update 
                        toShip.next = ShipTempB;
                        return noProblem; 
                    }

                }
            }
            else{
                return problem; 
			}
        } 
        catch (Exception e) {
            return problem; 
        }
	}
	
	/**
	 * Find a box with the identifier (if it exists)
	 * Remove the box from its corresponding shelf
	 * Add it to its corresponding shipping list
	 * @param identifier
	 * @return problem or noProblem
	 */
    public String shipBox (String identifier){
        //ADD YOUR CODE HERE
        for(int j = 0; j <nbShelves; j++ ){ //loop through the shelves 
            Box bufferBox = storage[j].firstBox; //loop thorugh all the boxes on shelf 
            while( bufferBox != null ){
                if( bufferBox.id.equals(identifier)){ // find the box! 
                    storage[j].removeBox(identifier); //remove box from shelf 
                    addToShip(bufferBox);
                    return noProblem;
                }
                bufferBox = bufferBox.next; 
			}
		}
		return problem; //can't find the box 
    }
	
	/**
	 * if there is a better shelf for the box, moves the box to the optimal shelf.
	 * If there are none, do not do anything
	 * @param b
	 * @param position
	 */
	public void moveOneBox (Box b, int position){
		//ADD YOUR CODE HERE
		int bheight = b.height; 
		
		for(int i=0;i<position;i++) {
			if( storage[i].height>= bheight && storage[i].availableLength>=b.length) {
					storage[position].removeBox(b.id);
					storage[i].addBox(b);
					break;
			
				}
	
			}

		}
	
	/**
	 * reorganize the entire warehouse : start with smaller shelves and first box on each shelf.
	 */
	public void reorganize (){
		//ADD YOUR CODE HERE
		Box curr;

		for (int i = 0; i <nbShelves; i++) {
			if (storage[i].availableLength == storage[i].totalLength) {
				continue;
			} 
			else {
				curr = this.storage[i].firstBox;
				Box temp = new Box(curr.height, curr.length, curr.id);
				temp.next = curr.next;
				temp.previous = curr.previous;
				moveOneBox(curr, i);
				curr= temp;
					while (curr.next != null) {
						curr = curr.next;
						temp.next = curr.next;
						temp.previous = curr.previous;
						moveOneBox(curr, i);
						curr= temp;

					}
			}
		}

	}
}


